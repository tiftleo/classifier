This directory should contain scripts and files needed to test your module's code.
 
