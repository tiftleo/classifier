This directory should contain any documentation you want to include about the
workings of your module that do not fit in either the root README.md or 
commentary in your code. 