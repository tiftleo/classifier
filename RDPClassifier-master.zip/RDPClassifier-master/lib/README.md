This directory should contain your module's code.
Run `make` in the root to generate your implementation files based on your typespec and the langauge directives in your Makefile.
This will also generate all language-specific client libraries.
