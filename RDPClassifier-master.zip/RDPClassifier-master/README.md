[![Build Status](https://travis-ci.org/tiftleo/RDPClassifier.svg?branch=master)](https://travis-ci.org/tiftleo/RDPClassifier)

# RDPClassifier
---

This is the basic readme for this module. Include any usage or deployment instructions and links to other documentation here.